﻿Public Class Emp_Log
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If UserTb.Text = "" Or PassTb.Text = "" Then
            MessageBox.Show("Enter Your Log in information")
        ElseIf UserTb.Text = "Employee" And PassTb.Text = "Password" Then
            Dim Main = New Emp_Main
            Main.Show()
            Me.Hide()
        End If



    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Application.Exit()


    End Sub
End Class