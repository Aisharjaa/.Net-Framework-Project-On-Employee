﻿Imports System.Data.SqlClient


Public Class Emp_Update

    Dim Con As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\EmployeeVbDb.mdf;Integrated Security=True;Connect Timeout=30")


    Private Sub Populate()

        Con.Open()
        Dim sql = "select *from EmployeeTable"
        Dim adapter As SqlDataAdapter
        adapter = New SqlDataAdapter(sql, Con)
        Dim builder As SqlCommandBuilder
        builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        EmployeedisDGV.DataSource = ds.Tables(0)
        Con.Close()


    End Sub

    Dim key = 0

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click


        If EmpNametb.Text = " " Or EmpMobtb.Text = "" Or EmpAddtb.Text = "" Then
            MessageBox.Show("missing information")
        Else
            Con.Open()
            Dim Query As String
            Query = "Update EmployeeTable set EmpName ='" & EmpNametb.Text & "', EmpAdd='" & EmpAddtb.Text & "', EmpPos=' " & PosCb.SelectedItem.ToString() & "', EmpDob='" & EmpDOB.Value & "',EmpMob='" & EmpMobtb.Text & "', EmpEdu='" & EmpEduCb.SelectedItem.ToString() & "',EmpGend='" & GendCb.SelectedItem.ToString() & "' where EmpId=" & key & " "

            Dim cmd As New SqlCommand(Query, Con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("employee updated")


            Con.Close()
            Populate()


        End If



    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Hide()
        Dim Main = New Emp_Main
        Main.Show()


    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click
        Application.Exit()
    End Sub
End Class