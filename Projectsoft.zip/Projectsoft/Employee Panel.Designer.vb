﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Employee_Panel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.EmpAdd = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.EmpPos = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.EmpEdu = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.EmpDob = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.EmpMob = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.EmpGender = New System.Windows.Forms.Label()
        Me.EmpIdtb = New System.Windows.Forms.TextBox()
        Me.EmpNamelbl = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.EmpAdd)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.EmpPos)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.EmpEdu)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.EmpDob)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.EmpMob)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.EmpGender)
        Me.Panel1.Controls.Add(Me.EmpIdtb)
        Me.Panel1.Controls.Add(Me.EmpNamelbl)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Location = New System.Drawing.Point(-1, 58)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1061, 417)
        Me.Panel1.TabIndex = 0
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.LightSalmon
        Me.Button3.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button3.Location = New System.Drawing.Point(600, 321)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(120, 65)
        Me.Button3.TabIndex = 47
        Me.Button3.Text = "Log out"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.LightSalmon
        Me.Button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button4.Location = New System.Drawing.Point(352, 323)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(119, 61)
        Me.Button4.TabIndex = 32
        Me.Button4.Text = "Home"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(68, 88)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(158, 22)
        Me.Label6.TabIndex = 35
        Me.Label6.Text = "Employee Name"
        '
        'EmpAdd
        '
        Me.EmpAdd.AutoSize = True
        Me.EmpAdd.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.EmpAdd.ForeColor = System.Drawing.Color.DarkRed
        Me.EmpAdd.Location = New System.Drawing.Point(785, 88)
        Me.EmpAdd.Name = "EmpAdd"
        Me.EmpAdd.Size = New System.Drawing.Size(182, 22)
        Me.EmpAdd.TabIndex = 46
        Me.EmpAdd.Text = "Employee Address"
        Me.EmpAdd.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(558, 88)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(182, 22)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "Employee Address"
        '
        'EmpPos
        '
        Me.EmpPos.AutoSize = True
        Me.EmpPos.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.EmpPos.ForeColor = System.Drawing.Color.DarkRed
        Me.EmpPos.Location = New System.Drawing.Point(785, 145)
        Me.EmpPos.Name = "EmpPos"
        Me.EmpPos.Size = New System.Drawing.Size(178, 22)
        Me.EmpPos.TabIndex = 45
        Me.EmpPos.Text = "Employee Position"
        Me.EmpPos.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(68, 145)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(173, 22)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "Employee Gender"
        '
        'EmpEdu
        '
        Me.EmpEdu.AutoSize = True
        Me.EmpEdu.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.EmpEdu.ForeColor = System.Drawing.Color.DarkRed
        Me.EmpEdu.Location = New System.Drawing.Point(785, 202)
        Me.EmpEdu.Name = "EmpEdu"
        Me.EmpEdu.Size = New System.Drawing.Size(197, 22)
        Me.EmpEdu.TabIndex = 44
        Me.EmpEdu.Text = "Employee Education"
        Me.EmpEdu.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(562, 145)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(178, 22)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "Employee Position"
        '
        'EmpDob
        '
        Me.EmpDob.AutoSize = True
        Me.EmpDob.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.EmpDob.ForeColor = System.Drawing.Color.DarkRed
        Me.EmpDob.Location = New System.Drawing.Point(270, 263)
        Me.EmpDob.Name = "EmpDob"
        Me.EmpDob.Size = New System.Drawing.Size(148, 22)
        Me.EmpDob.TabIndex = 43
        Me.EmpDob.Text = "Employee DOB"
        Me.EmpDob.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(543, 202)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(197, 22)
        Me.Label2.TabIndex = 29
        Me.Label2.Text = "Employee Education"
        '
        'EmpMob
        '
        Me.EmpMob.AutoSize = True
        Me.EmpMob.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.EmpMob.ForeColor = System.Drawing.Color.DarkRed
        Me.EmpMob.Location = New System.Drawing.Point(270, 202)
        Me.EmpMob.Name = "EmpMob"
        Me.EmpMob.Size = New System.Drawing.Size(201, 22)
        Me.EmpMob.TabIndex = 42
        Me.EmpMob.Text = "Employee Mobile No."
        Me.EmpMob.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(96, 263)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(148, 22)
        Me.Label7.TabIndex = 36
        Me.Label7.Text = "Employee DOB"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(231, 25)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(125, 22)
        Me.Label9.TabIndex = 38
        Me.Label9.Text = "Employee ID"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(63, 202)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(201, 22)
        Me.Label8.TabIndex = 37
        Me.Label8.Text = "Employee Mobile No."
        '
        'EmpGender
        '
        Me.EmpGender.AutoSize = True
        Me.EmpGender.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.EmpGender.ForeColor = System.Drawing.Color.DarkRed
        Me.EmpGender.Location = New System.Drawing.Point(270, 145)
        Me.EmpGender.Name = "EmpGender"
        Me.EmpGender.Size = New System.Drawing.Size(173, 22)
        Me.EmpGender.TabIndex = 41
        Me.EmpGender.Text = "Employee Gender"
        Me.EmpGender.Visible = False
        '
        'EmpIdtb
        '
        Me.EmpIdtb.Location = New System.Drawing.Point(415, 28)
        Me.EmpIdtb.Name = "EmpIdtb"
        Me.EmpIdtb.Size = New System.Drawing.Size(169, 23)
        Me.EmpIdtb.TabIndex = 39
        '
        'EmpNamelbl
        '
        Me.EmpNamelbl.AutoSize = True
        Me.EmpNamelbl.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.EmpNamelbl.ForeColor = System.Drawing.Color.DarkRed
        Me.EmpNamelbl.Location = New System.Drawing.Point(270, 88)
        Me.EmpNamelbl.Name = "EmpNamelbl"
        Me.EmpNamelbl.Size = New System.Drawing.Size(158, 22)
        Me.EmpNamelbl.TabIndex = 40
        Me.EmpNamelbl.Text = "Employee Name"
        Me.EmpNamelbl.Visible = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.LightSalmon
        Me.Button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button2.Location = New System.Drawing.Point(662, 19)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(132, 39)
        Me.Button2.TabIndex = 34
        Me.Button2.Text = "Search"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Employee_Panel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(1062, 504)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Employee_Panel"
        Me.Text = "Employee_Panel"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents EmpAdd As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents EmpPos As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents EmpEdu As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents EmpDob As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents EmpMob As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents EmpGender As Label
    Friend WithEvents EmpIdtb As TextBox
    Friend WithEvents EmpNamelbl As Label
    Friend WithEvents Button2 As Button
End Class
