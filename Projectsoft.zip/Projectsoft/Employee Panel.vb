﻿Imports System.Data.SqlClient

Public Class Employee_Panel


    Dim Con As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\EmployeeVbDb.mdf;Integrated Security=True;Connect Timeout=30")

    Private Sub salarytb_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Hide()
        Dim Main = New Emp_Main
        Main.Show()




    End Sub


    Private Sub FetchEmployeeData()

        If EmpIdtb.Text = " " Then
            MessageBox.Show("Please enter a ID for search")

        Else


            Con.Open()
            Dim Query = "select * from EmployeeTable where EmpId=" & EmpIdtb.Text & "                   "
            Dim cmd As SqlCommand
            cmd = New SqlCommand(Query, Con)
            Dim dt As DataTable
            dt = New DataTable
            Dim sda As SqlDataAdapter
            sda = New SqlDataAdapter(cmd)
            sda.Fill(dt)

            For Each dr As DataRow In dt.Rows


                EmpNamelbl.Text = dr(1).ToString()
                EmpAdd.Text = dr(2).ToString()
                EmpPos.Text = dr(3).ToString()
                EmpDob.Text = dr(4).ToString()
                EmpMob.Text = dr(6).ToString()
                EmpEdu.Text = dr(5).ToString()
                EmpGender.Text = dr(7).ToString()


                EmpNamelbl.Visible = True
                EmpAdd.Visible = True
                EmpPos.Visible = True
                EmpDob.Visible = True
                EmpMob.Visible = True
                EmpEdu.Visible = True
                EmpGender.Visible = True

            Next
            Con.Close()


        End If












    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        FetchEmployeeData()









    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Application.Exit()

    End Sub
End Class