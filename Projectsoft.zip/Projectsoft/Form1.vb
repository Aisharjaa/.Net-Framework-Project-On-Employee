﻿Public Class Form1
    Private Sub Timer1_Ticker(sender As Object, e As EventArgs) Handles Timer1.Tick
        Myprogress.Increment(1)

        If Myprogress.Value = 100 Then
            Me.Hide()
            Dim log = New choice
            log.Show()
            Timer1.Enabled = False
        End If



    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Timer1.Start()





    End Sub

    Private Sub Myprogress_Click(sender As Object, e As EventArgs) Handles Myprogress.Click

    End Sub
End Class
