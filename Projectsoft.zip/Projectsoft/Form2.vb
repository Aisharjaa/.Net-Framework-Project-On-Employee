﻿Public Class Form2
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        UserTb.Clear()
        PassTb.Clear()





    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

        Application.Exit()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If UserTb.Text = "" Or PassTb.Text = "" Then
            MessageBox.Show("Enter Your Log in information")
        ElseIf UserTb.Text = "Admin" And PassTb.Text = "Password" Then
            Dim Main = New Form3
            Main.Show()
            Me.Hide()
        End If

    End Sub
End Class