﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.EmployeedisDGV = New System.Windows.Forms.DataGridView()
        Me.EmpEduCb = New System.Windows.Forms.ComboBox()
        Me.PosCb = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GendCb = New System.Windows.Forms.ComboBox()
        Me.EmpDOB = New System.Windows.Forms.DateTimePicker()
        Me.EmpAddtb = New System.Windows.Forms.TextBox()
        Me.EmpMobtb = New System.Windows.Forms.TextBox()
        Me.EmpNametb = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.EmployeedisDGV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.EmployeedisDGV)
        Me.Panel1.Controls.Add(Me.EmpEduCb)
        Me.Panel1.Controls.Add(Me.PosCb)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.GendCb)
        Me.Panel1.Controls.Add(Me.EmpDOB)
        Me.Panel1.Controls.Add(Me.EmpAddtb)
        Me.Panel1.Controls.Add(Me.EmpMobtb)
        Me.Panel1.Controls.Add(Me.EmpNametb)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Location = New System.Drawing.Point(12, 75)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(958, 496)
        Me.Panel1.TabIndex = 0
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(3, 422)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(120, 46)
        Me.Button4.TabIndex = 6
        Me.Button4.Text = "Home"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(154, 422)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(120, 46)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "Delete"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(308, 422)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(120, 46)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Edit"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'EmployeedisDGV
        '
        Me.EmployeedisDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.EmployeedisDGV.Location = New System.Drawing.Point(632, 3)
        Me.EmployeedisDGV.Name = "EmployeedisDGV"
        Me.EmployeedisDGV.RowTemplate.Height = 25
        Me.EmployeedisDGV.Size = New System.Drawing.Size(307, 465)
        Me.EmployeedisDGV.TabIndex = 21
        '
        'EmpEduCb
        '
        Me.EmpEduCb.FormattingEnabled = True
        Me.EmpEduCb.Items.AddRange(New Object() {"JSC", "SSC", "HSC", "BBA ", "BSc", "MBA", "MSc", "Diploma"})
        Me.EmpEduCb.Location = New System.Drawing.Point(15, 262)
        Me.EmpEduCb.Name = "EmpEduCb"
        Me.EmpEduCb.Size = New System.Drawing.Size(182, 23)
        Me.EmpEduCb.TabIndex = 20
        '
        'PosCb
        '
        Me.PosCb.FormattingEnabled = True
        Me.PosCb.Items.AddRange(New Object() {"Manager", "IT ", "Worker", "HR", "Audit", "Accountant", "Engineers"})
        Me.PosCb.Location = New System.Drawing.Point(15, 166)
        Me.PosCb.Name = "PosCb"
        Me.PosCb.Size = New System.Drawing.Size(182, 23)
        Me.PosCb.TabIndex = 19
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(472, 422)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(120, 46)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Add"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'GendCb
        '
        Me.GendCb.FormattingEnabled = True
        Me.GendCb.Items.AddRange(New Object() {"Male", "Female"})
        Me.GendCb.Location = New System.Drawing.Point(371, 262)
        Me.GendCb.Name = "GendCb"
        Me.GendCb.Size = New System.Drawing.Size(169, 23)
        Me.GendCb.TabIndex = 17
        '
        'EmpDOB
        '
        Me.EmpDOB.Font = New System.Drawing.Font("Century Schoolbook", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.EmpDOB.Location = New System.Drawing.Point(371, 166)
        Me.EmpDOB.Name = "EmpDOB"
        Me.EmpDOB.Size = New System.Drawing.Size(221, 27)
        Me.EmpDOB.TabIndex = 16
        '
        'EmpAddtb
        '
        Me.EmpAddtb.Location = New System.Drawing.Point(371, 73)
        Me.EmpAddtb.Name = "EmpAddtb"
        Me.EmpAddtb.Size = New System.Drawing.Size(182, 23)
        Me.EmpAddtb.TabIndex = 15
        '
        'EmpMobtb
        '
        Me.EmpMobtb.Location = New System.Drawing.Point(15, 367)
        Me.EmpMobtb.Name = "EmpMobtb"
        Me.EmpMobtb.Size = New System.Drawing.Size(173, 23)
        Me.EmpMobtb.TabIndex = 12
        '
        'EmpNametb
        '
        Me.EmpNametb.Location = New System.Drawing.Point(15, 73)
        Me.EmpNametb.Name = "EmpNametb"
        Me.EmpNametb.Size = New System.Drawing.Size(169, 23)
        Me.EmpNametb.TabIndex = 10
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(15, 323)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(201, 22)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Employee Mobile No."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(371, 131)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(148, 22)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Employee DOB"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(15, 226)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(197, 22)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Employee Education"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(15, 131)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(178, 22)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Employee Position"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(371, 226)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(173, 22)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Employee Gender"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(371, 48)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(182, 22)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Employee Address"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(15, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(158, 22)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Employee Name"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(15, 20)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(135, 48)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(181, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(296, 22)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Employee Management System"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(934, 9)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(21, 22)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "X"
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(973, 574)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form4"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form4"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.EmployeedisDGV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents GendCb As ComboBox
    Friend WithEvents EmpDOB As DateTimePicker
    Friend WithEvents EmpAddtb As TextBox
    Friend WithEvents EmpMobtb As TextBox
    Friend WithEvents EmpNametb As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents EmployeedisDGV As DataGridView
    Friend WithEvents EmpEduCb As ComboBox
    Friend WithEvents PosCb As ComboBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label10 As Label
End Class
