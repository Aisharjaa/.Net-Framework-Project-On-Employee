﻿Imports System.Data.SqlClient



Public Class Form4

    Dim Con As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\EmployeeVbDb.mdf;Integrated Security=True;Connect Timeout=30")






    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Populate()

    End Sub

    Private Sub Populate()

        Con.Open()
        Dim sql = "select *from EmployeeTable"
        Dim adapter As SqlDataAdapter
        adapter = New SqlDataAdapter(sql, Con)
        Dim builder As SqlCommandBuilder
        builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        EmployeedisDGV.DataSource = ds.Tables(0)
        Con.Close()


    End Sub



    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles EmpNametb.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click




        Con.Open()

        Dim Query As String

        Query = "insert into EmployeeTable values( ' " & EmpNametb.Text & " ', ' " & EmpAddtb.Text & " ', '" & PosCb.SelectedItem.ToString() & "', '" & EmpDOB.Value & "','" & EmpEduCb.SelectedItem.ToString() & "', '" & EmpMobtb.Text & "', '" & GendCb.SelectedItem.ToString() & " ' )"



        Dim cmd As SqlCommand
        cmd = New SqlCommand(Query, Con)

        cmd.ExecuteNonQuery()



        MessageBox.Show("Employee Added")




        Con.Close()
        Populate()
        Clear()




    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles EmployeedisDGV.CellContentClick

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs)

    End Sub



    Dim key = 0

    Private Sub Clear()

        EmpNametb.Clear()
        PosCb.Text = ""
        GendCb.Text = ""
        EmpAddtb.Text = ""
        key = 0
        EmpEduCb.Text = ""
        EmpMobtb.Text = ""


    End Sub



    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        If key = 0 Then
            MessageBox.Show("Select Employee member to be resigned")
        Else
            Try
                Con.Open()
                Dim Query As String
                Query = "Delete from EmployeeTable where EmpId=" & key & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(Query, Con)
                cmd.ExecuteNonQuery()
                MessageBox.Show("employee deleted")
                Con.Close()
                Populate()
                Clear()
            Catch ex As Exception
                MessageBox.Show(ex.Message)

            End Try

        End If


    End Sub

    Private Sub EmployeedisDGV_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles EmployeedisDGV.CellMouseClick
        Dim row As DataGridViewRow = EmployeedisDGV.Rows(e.RowIndex)
        key = Convert.ToInt32(row.Cells(0).Value.ToString())
        EmpNametb.Text = row.Cells(1).Value.ToString()
        EmpAddtb.Text = row.Cells(2).Value.ToString()
        PosCb.SelectedItem = row.Cells(3).Value.ToString()
        EmpDOB.Value = row.Cells(4).Value.ToString()
        EmpEduCb.SelectedItem = row.Cells(5).Value.ToString()
        EmpMobtb.Text = row.Cells(6).Value.ToString()
        GendCb.SelectedItem = row.Cells(7).Value.ToString()


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        If EmpNametb.Text = " " Or EmpMobtb.Text = "" Or EmpAddtb.Text = "" Then
            MessageBox.Show("missing information")
        Else
            Con.Open()
            Dim Query As String
            Query = "Update EmployeeTable set EmpName ='" & EmpNametb.Text & "', EmpAdd='" & EmpAddtb.Text & "', EmpPos=' " & PosCb.SelectedItem.ToString() & "', EmpDob='" & EmpDOB.Value & "',EmpMob='" & EmpEduCb.SelectedItem.ToString() & "', EmpEdu='" & EmpMobtb.Text & "',EmpGend='" & GendCb.SelectedItem.ToString() & "' where EmpId=" & key & " "

            Dim cmd As New SqlCommand(Query, Con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("employee updated")


            Con.Close()
            Populate()
            Clear()

        End If





    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

        Application.Exit()


    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Hide()
        Dim Main = New Form3
        Main.Show()

    End Sub
End Class