﻿Imports System.Data.SqlClient

Public Class Form5



    Dim Con As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\EmployeeVbDb.mdf;Integrated Security=True;Connect Timeout=30")

    Private Sub FetchEmployeeData()

        If EmpIdtb.Text = " " Then
            MessageBox.Show("Please enter a ID for search")

        Else


            Con.Open()
            Dim Query = "select * from EmployeeTable where EmpId=" & EmpIdtb.Text & "                   "
        Dim cmd As SqlCommand
        cmd = New SqlCommand(Query, Con)
        Dim dt As DataTable
        dt = New DataTable
        Dim sda As SqlDataAdapter
        sda = New SqlDataAdapter(cmd)
        sda.Fill(dt)

            For Each dr As DataRow In dt.Rows


                EmpNamelbl.Text = dr(1).ToString()
                EmpAdd.Text = dr(2).ToString()
                EmpPos.Text = dr(3).ToString()
                EmpDob.Text = dr(4).ToString()
                EmpEdu.Text = dr(5).ToString()
                EmpMob.Text = dr(6).ToString()
                EmpGender.Text = dr(7).ToString()


                EmpNamelbl.Visible = True
                EmpAdd.Visible = True
                EmpPos.Visible = True
                EmpDob.Visible = True
                EmpMob.Visible = True
                EmpEdu.Visible = True
                EmpGender.Visible = True

            Next
            Con.Close()


            End If












    End Sub




    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles EmpIdtb.TextChanged

    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click


        FetchEmployeeData()








    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        Me.Hide()
        Dim Main = New Form3
        Main.Show()



    End Sub



    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub
End Class