﻿Imports System.Data.SqlClient




Public Class Salary

    Dim Con As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\EmployeeVbDb.mdf;Integrated Security=True;Connect Timeout=30")

    Private Sub FetchEmployeeData()

        If EmpIdtb.Text = " " Then
            MessageBox.Show("Please enter a ID for search")

        Else


            Con.Open()
            Dim Query = "select * from EmployeeTable where EmpId=" & EmpIdtb.Text & "                   "
            Dim cmd As SqlCommand
            cmd = New SqlCommand(Query, Con)
            Dim dt As DataTable
            dt = New DataTable
            Dim sda As SqlDataAdapter
            sda = New SqlDataAdapter(cmd)
            sda.Fill(dt)

            For Each dr As DataRow In dt.Rows


                EmpNamelbl.Text = dr(1).ToString()

                EmpPos.Text = dr(3).ToString()



                EmpNamelbl.Visible = True

                EmpPos.Visible = True


            Next
            Con.Close()


        End If












    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Me.Hide()
        Dim Main = New Form3

        Main.Show()



    End Sub

    Private Sub Salary_Load(sender As Object, e As EventArgs) Handles MyBase.Load




    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        FetchEmployeeData()


    End Sub

    Private Sub EmpNamelbl_Click(sender As Object, e As EventArgs) Handles EmpNamelbl.Click

    End Sub

    Dim daypay

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        If EmpPos.Text = "" Then
            MessageBox.Show("select an employee")
        ElseIf Worktb.Text = " " Or Convert.ToInt32(Worktb.Text) > 28 Then
            MessageBox.Show("enter valid number of days")
        Else
            If EmpPos.Text = "Manager" Then
                daypay = 1900

            ElseIf EmpPos.Text = "HR" Then
                daypay = 820

            ElseIf EmpPos.Text = "IT" Then
                daypay = 219

            ElseIf EmpPos.Text = "Audit" Then
                daypay = 543

            ElseIf EmpPos.Text = "Accountant" Then
                daypay = 3386

            ElseIf EmpPos.Text = "Engineer" Then
                daypay = 733

            ElseIf EmpPos.Text = "Worker" Then
                daypay = 210
            Else
                daypay = 500


            End If
            Dim total = daypay * Convert.ToInt32(Worktb.Text)
            salarytb.Text = "Employee id: " + EmpIdtb.Text + vbCrLf + "Employee Name: " + EmpNamelbl.Text + vbCrLf + "Employee Possition: " + EmpPos.Text + vbCrLf + "Days Worked  " + Worktb.Text + vbCrLf + "Daily salary  " + Convert.ToString(daypay) + vbCrLf + "Monthend Salary" + Convert.ToString(total)
        End If




    End Sub




    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawString("Employee Management System", New Font("Century Gothic", 25), Brushes.DarkGreen, 180, 40)
        e.Graphics.DrawString("*****Payslip****", New Font("Arial", 20), Brushes.Crimson, 330, 100)
        e.Graphics.DrawString(salarytb.Text, New Font("Century Gothic", 20), Brushes.Black, 150, 190)

        e.Graphics.DrawString("*******Thanks for using our service********", New Font("Century Gothic", 15), Brushes.DarkGreen, 150, 500)




    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        PrintPreviewDialog1.Show()

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

        Application.Exit()


    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub
End Class