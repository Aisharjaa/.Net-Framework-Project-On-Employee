﻿Public Class choice
    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

        Application.Exit()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Dim log = New Form2
        log.Show()



    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

        Me.Hide()
        Dim log = New Form2
        log.Show()

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

        Me.Hide()
        Dim log = New Emp_Log
        log.Show()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Me.Hide()
        Dim log = New Emp_Log
        log.Show()


    End Sub
End Class